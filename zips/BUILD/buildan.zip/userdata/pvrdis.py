#!/usr/bin/python
# -*- coding: utf-8 -*-
#import xbmc,xbmcgui,xbmcplugin
import xbmc

xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":8,"params":{"addonid":"pvr.stalker64","enabled":false}}')