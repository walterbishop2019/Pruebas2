import xbmcaddon
xbmcaddon.Addon('pvr.stalker').openSettings()