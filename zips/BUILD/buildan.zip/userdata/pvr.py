import xbmcaddon
xbmcaddon.Addon('pvr.stalker64').openSettings()