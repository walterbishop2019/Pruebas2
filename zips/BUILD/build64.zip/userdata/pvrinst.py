#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon
import time
		
xbmc.executebuiltin('InstallAddon(pvr.stalker)')
xbmc.executebuiltin('SendClick(11)'), time.sleep(2), xbmcgui.Dialog().ok("Se instaleaza addonul", "Addonul este in curs de instalare.")
time.sleep(1)
xbmc.executebuiltin("Container.Refresh")