#!/usr/bin/python
# -*- coding: utf-8 -*-
#import xbmc,xbmcgui,xbmcplugin
import xbmc

xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":9,"params":{"addonid":"pvr.stalker","enabled":true}}')